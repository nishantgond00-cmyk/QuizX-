
import React from 'react';
import { Subject } from './types.ts';

export const SUBJECT_DATA: Subject[] = [
  { id: 'GK', title: 'GK', description: 'General Knowledge & Current Affairs', icon: '🌍' },
  { id: 'GS', title: 'GS', description: 'General Science fundamentals', icon: '🔬' },
  { id: 'PHYSICS', title: 'Physics', description: 'Laws of motion, energy, and matter', icon: '⚡' },
  { id: 'MATH', title: 'Mathematics', description: 'Arithmetic, Algebra, and Geometry', icon: '📐' },
  { id: 'SSC', title: 'SSC', description: 'Staff Selection Commission exams', icon: '💼' },
  { id: 'ONEDAY', title: 'One Day Exam', description: 'Competitive recruitment tests', icon: '⏱️' },
];

export const MAX_LEVELS = 50;
export const PASS_MARK = 6;
export const QUESTIONS_PER_LEVEL = 10;
