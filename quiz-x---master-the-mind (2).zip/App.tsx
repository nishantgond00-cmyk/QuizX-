
import React, { useState, useEffect } from 'react';
import { SubjectId, UserProgress } from './types.ts';
import { SUBJECT_DATA, MAX_LEVELS, PASS_MARK } from './constants.tsx';
import { getQuestionsForLevel } from './data/questions.ts';

// Screens
import Home from './components/Home.tsx';
import SubjectSelection from './components/SubjectSelection.tsx';
import LevelSelection from './components/LevelSelection.tsx';
import Quiz from './components/Quiz.tsx';

const App: React.FC = () => {
  const [screen, setScreen] = useState<'HOME' | 'SUBJECTS' | 'LEVELS' | 'QUIZ'>('HOME');
  const [selectedSubject, setSelectedSubject] = useState<SubjectId | null>(null);
  const [selectedLevel, setSelectedLevel] = useState<number>(1);
  const [progress, setProgress] = useState<UserProgress>({});

  // Initialize progress from localStorage
  useEffect(() => {
    const saved = localStorage.getItem('quiz_x_progress');
    if (saved) {
      setProgress(JSON.parse(saved));
    } else {
      // Default initial state: Level 1 of all subjects unlocked
      const initial: UserProgress = {};
      SUBJECT_DATA.forEach(s => {
        initial[s.id] = {
          '1': { unlocked: true, completed: false, score: 0, stars: 0 }
        };
      });
      setProgress(initial);
      localStorage.setItem('quiz_x_progress', JSON.stringify(initial));
    }
  }, []);

  const saveProgress = (subject: SubjectId, level: number, score: number) => {
    const stars = score >= 9 ? 3 : score >= 7 ? 2 : score >= 6 ? 1 : 0;
    const isPassed = score >= PASS_MARK;

    const newProgress = { ...progress };
    if (!newProgress[subject]) newProgress[subject] = {};
    
    // Update current level
    newProgress[subject][level] = {
      ...newProgress[subject][level],
      score: Math.max(score, newProgress[subject][level]?.score || 0),
      stars: Math.max(stars, newProgress[subject][level]?.stars || 0),
      completed: isPassed || (newProgress[subject][level]?.completed),
      unlocked: true,
    };

    // Unlock next level if passed
    if (isPassed && level < MAX_LEVELS) {
      const nextLevel = level + 1;
      if (!newProgress[subject][nextLevel]) {
        newProgress[subject][nextLevel] = {
          unlocked: true,
          completed: false,
          score: 0,
          stars: 0
        };
      } else {
        newProgress[subject][nextLevel].unlocked = true;
      }
    }

    setProgress(newProgress);
    localStorage.setItem('quiz_x_progress', JSON.stringify(newProgress));
  };

  const handleStart = () => setScreen('SUBJECTS');
  
  const handleSelectSubject = (id: SubjectId) => {
    setSelectedSubject(id);
    setScreen('LEVELS');
  };

  const handleSelectLevel = (lvl: number) => {
    setSelectedLevel(lvl);
    setScreen('QUIZ');
  };

  const handleQuizComplete = (score: number) => {
    if (selectedSubject) {
      saveProgress(selectedSubject, selectedLevel, score);
    }
  };

  const goBack = () => {
    if (screen === 'QUIZ') setScreen('LEVELS');
    else if (screen === 'LEVELS') setScreen('SUBJECTS');
    else if (screen === 'SUBJECTS') setScreen('HOME');
  };

  return (
    <div className="min-h-screen bg-black text-white selection:bg-white selection:text-black overflow-x-hidden">
      {screen === 'HOME' && <Home onStart={handleStart} />}
      
      {screen === 'SUBJECTS' && (
        <SubjectSelection 
          subjects={SUBJECT_DATA} 
          onSelect={handleSelectSubject} 
          onBack={goBack} 
        />
      )}

      {screen === 'LEVELS' && selectedSubject && (
        <LevelSelection 
          subject={SUBJECT_DATA.find(s => s.id === selectedSubject)!}
          progress={progress[selectedSubject] || {}}
          onSelect={handleSelectLevel}
          onBack={goBack}
        />
      )}

      {screen === 'QUIZ' && selectedSubject && (
        <Quiz 
          subjectId={selectedSubject}
          level={selectedLevel}
          questions={getQuestionsForLevel(selectedSubject, selectedLevel)}
          onComplete={handleQuizComplete}
          onBack={goBack}
        />
      )}
    </div>
  );
};

export default App;
