
import React from 'react';

interface HomeProps {
  onStart: () => void;
}

const Home: React.FC<HomeProps> = ({ onStart }) => {
  return (
    <div className="flex flex-col items-center justify-center min-h-screen px-6 py-12 text-center">
      <div className="mb-8 group cursor-default">
        <div className="relative w-32 h-32 md:w-48 md:h-48 border-8 border-white flex items-center justify-center bg-black transition-all duration-500 group-hover:bg-white">
          <span className="text-7xl md:text-9xl font-heading font-black text-white group-hover:text-black transition-colors">Q</span>
          <div className="absolute -bottom-4 -right-4 w-12 h-12 md:w-20 md:h-20 bg-white border-4 border-black flex items-center justify-center transition-all duration-500 group-hover:bg-black group-hover:border-white">
            <span className="text-2xl md:text-4xl font-heading font-black text-black group-hover:text-white transition-colors">X</span>
          </div>
        </div>
      </div>

      <h1 className="text-5xl md:text-7xl font-heading font-bold mb-4 tracking-tighter">
        QUIZ <span className="text-transparent bg-clip-text bg-gradient-to-r from-gray-400 to-white">X</span>
      </h1>
      
      <p className="max-w-md text-gray-400 text-lg mb-12 font-light leading-relaxed">
        Master your chosen field with 3,000+ hand-picked challenges.
        Solve, progress, and unlock your potential.
      </p>

      <div className="relative group">
        <button 
          onClick={onStart}
          className="relative z-10 bg-white text-black px-12 py-4 text-xl font-bold uppercase tracking-widest hover:bg-gray-200 transition-colors"
        >
          START MISSION
        </button>
        <div className="absolute -bottom-2 -right-2 w-full h-full border-2 border-white group-hover:-bottom-1 group-hover:-right-1 transition-all"></div>
      </div>

      <div className="mt-20 grid grid-cols-3 gap-8 opacity-20 grayscale">
        <div className="flex flex-col items-center">
          <div className="w-12 h-12 border border-white rotate-45 mb-2"></div>
          <span className="text-xs uppercase tracking-tighter">Logic</span>
        </div>
        <div className="flex flex-col items-center">
          <div className="w-12 h-12 border border-white rounded-full mb-2"></div>
          <span className="text-xs uppercase tracking-tighter">Skill</span>
        </div>
        <div className="flex flex-col items-center">
          <div className="w-12 h-12 border border-white mb-2"></div>
          <span className="text-xs uppercase tracking-tighter">Data</span>
        </div>
      </div>
    </div>
  );
};

export default Home;
