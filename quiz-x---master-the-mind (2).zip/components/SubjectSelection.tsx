
import React from 'react';
import { Subject, SubjectId } from '../types';

interface SubjectSelectionProps {
  subjects: Subject[];
  onSelect: (id: SubjectId) => void;
  onBack: () => void;
}

const SubjectSelection: React.FC<SubjectSelectionProps> = ({ subjects, onSelect, onBack }) => {
  return (
    <div className="max-w-6xl mx-auto px-6 py-12">
      <header className="mb-12 flex items-center justify-between">
        <div>
          <h2 className="text-4xl font-heading font-bold mb-2">CATEGORIES</h2>
          <p className="text-gray-500 uppercase tracking-widest text-sm">Choose your discipline</p>
        </div>
        <button 
          onClick={onBack}
          className="text-gray-400 hover:text-white transition-colors flex items-center gap-2 group"
        >
          <span className="group-hover:-translate-x-1 transition-transform">←</span> BACK
        </button>
      </header>

      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
        {subjects.map((sub) => (
          <button
            key={sub.id}
            onClick={() => onSelect(sub.id)}
            className="group relative bg-zinc-900 border border-zinc-800 p-8 text-left transition-all hover:border-white hover:bg-zinc-800 overflow-hidden"
          >
            <div className="relative z-10">
              <span className="text-4xl mb-4 block group-hover:scale-110 transition-transform origin-left">
                {sub.icon}
              </span>
              <h3 className="text-2xl font-bold mb-2 uppercase tracking-tight">{sub.title}</h3>
              <p className="text-zinc-500 text-sm group-hover:text-zinc-300 transition-colors">
                {sub.description}
              </p>
            </div>
            <div className="absolute top-0 right-0 p-4 opacity-0 group-hover:opacity-100 transition-opacity">
              <div className="w-8 h-8 border-t-2 border-r-2 border-white"></div>
            </div>
          </button>
        ))}
      </div>
    </div>
  );
};

export default SubjectSelection;
