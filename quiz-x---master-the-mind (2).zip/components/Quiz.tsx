
import React, { useState, useEffect } from 'react';
import { SubjectId, Question } from '../types.ts';
import { PASS_MARK } from '../constants.tsx';

interface QuizProps {
  subjectId: SubjectId;
  level: number;
  questions: Question[];
  onComplete: (score: number) => void;
  onBack: () => void;
}

const Quiz: React.FC<QuizProps> = ({ subjectId, level, questions, onComplete, onBack }) => {
  const [currentIndex, setCurrentIndex] = useState(0);
  const [selectedOption, setSelectedOption] = useState<number | null>(null);
  const [isAnswered, setIsAnswered] = useState(false);
  const [score, setScore] = useState(0);
  const [isFinished, setIsFinished] = useState(false);
  const [shake, setShake] = useState(false);

  const currentQuestion = questions[currentIndex];

  const handleSelect = (idx: number) => {
    if (isAnswered) return;
    
    setSelectedOption(idx);
    setIsAnswered(true);

    const isCorrect = idx === currentQuestion.correctAnswer;
    if (isCorrect) {
      setScore(s => s + 1);
    } else {
      setShake(true);
      if (window.navigator.vibrate) {
        window.navigator.vibrate(200);
      }
      setTimeout(() => setShake(false), 500);
    }

    // Move to next question after a short delay
    setTimeout(() => {
      if (currentIndex < questions.length - 1) {
        setCurrentIndex(c => c + 1);
        setSelectedOption(null);
        setIsAnswered(false);
      } else {
        setIsFinished(true);
        // We pass the final score after the last answer is processed
        onComplete(isCorrect ? score + 1 : score);
      }
    }, 1000);
  };

  if (isFinished) {
    const finalScore = score;
    const passed = finalScore >= PASS_MARK;
    
    return (
      <div className="flex flex-col items-center justify-center min-h-[80vh] px-6 text-center animate-in fade-in zoom-in duration-500">
        <div className={`text-9xl mb-8 ${passed ? 'text-white' : 'text-zinc-800'}`}>
          {passed ? '🏆' : '💀'}
        </div>
        <h2 className="text-5xl font-heading font-bold mb-4 uppercase tracking-tighter">
          {passed ? 'Mission Success' : 'Mission Failed'}
        </h2>
        <p className="text-zinc-400 text-xl mb-12">
          Final Score: <span className="text-white font-mono font-bold">{finalScore} / {questions.length}</span>
        </p>
        
        <div className="flex flex-col gap-4 w-full max-w-sm">
          {passed ? (
             <button 
               onClick={onBack}
               className="bg-white text-black py-5 text-lg font-bold uppercase tracking-widest hover:bg-zinc-200 transition-colors"
             >
               Next Challenge
             </button>
          ) : (
             <button 
               onClick={() => {
                  setCurrentIndex(0);
                  setSelectedOption(null);
                  setIsAnswered(false);
                  setScore(0);
                  setIsFinished(false);
               }}
               className="bg-zinc-800 text-white py-5 text-lg font-bold uppercase tracking-widest hover:bg-zinc-700 transition-colors border border-zinc-700"
             >
               Retry Mission
             </button>
          )}
          <button 
            onClick={onBack} 
            className="text-zinc-500 uppercase text-xs tracking-[0.3em] mt-4 hover:text-white transition-colors"
          >
            Return to Command Center
          </button>
        </div>
      </div>
    );
  }

  const progressPercent = ((currentIndex) / questions.length) * 100;

  return (
    <div className={`max-w-3xl mx-auto px-6 py-12 ${shake ? 'shake' : ''}`}>
      <header className="flex items-center justify-between mb-12">
        <button onClick={onBack} className="text-zinc-500 hover:text-white transition-colors text-sm font-bold tracking-widest">
          ✕ ABORT
        </button>
        <div className="text-right">
          <span className="text-[10px] text-zinc-500 block uppercase tracking-widest mb-1">{subjectId} LEVEL {level}</span>
          <span className="font-mono text-xl font-bold">{currentIndex + 1} <span className="text-zinc-700">/</span> {questions.length}</span>
        </div>
      </header>

      <div className="w-full h-[2px] bg-zinc-900 mb-16">
        <div 
          className="h-full bg-white transition-all duration-500 ease-out"
          style={{ width: `${progressPercent}%` }}
        ></div>
      </div>

      <div className="mb-16">
        <h3 className="text-3xl md:text-4xl font-heading font-bold leading-tight tracking-tight">
          {currentQuestion.text}
        </h3>
      </div>

      <div className="grid grid-cols-1 gap-4">
        {currentQuestion.options.map((opt, idx) => {
          let stateStyles = 'bg-transparent border-zinc-800 hover:border-zinc-400 hover:bg-zinc-900';
          
          if (isAnswered) {
            if (idx === currentQuestion.correctAnswer) {
              stateStyles = 'bg-white text-black border-white';
            } else if (idx === selectedOption) {
              stateStyles = 'bg-red-900 border-red-700 text-white';
            } else {
              stateStyles = 'bg-zinc-950 border-zinc-900 text-zinc-700 opacity-50';
            }
          }

          return (
            <button
              key={idx}
              disabled={isAnswered}
              onClick={() => handleSelect(idx)}
              className={`
                p-6 text-left border transition-all duration-300 flex items-center justify-between group
                ${stateStyles}
              `}
            >
              <span className="text-lg font-medium">{opt}</span>
              <span className={`text-xs font-mono opacity-30 ${isAnswered ? 'hidden' : 'block'}`}>[0{idx + 1}]</span>
            </button>
          );
        })}
      </div>

      <div className="mt-16 pt-8 border-t border-zinc-900 flex justify-between items-center text-[10px] text-zinc-600 uppercase tracking-[0.2em]">
        <span>Pass requirement: {PASS_MARK}/10</span>
        <span>Score: {score}</span>
      </div>
    </div>
  );
};

export default Quiz;
