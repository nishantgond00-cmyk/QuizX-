
import React from 'react';
import { Subject, LevelProgress } from '../types.ts';
import { MAX_LEVELS } from '../constants.tsx';

interface LevelSelectionProps {
  subject: Subject;
  progress: { [lvl: string]: LevelProgress };
  onSelect: (lvl: number) => void;
  onBack: () => void;
}

const LevelSelection: React.FC<LevelSelectionProps> = ({ subject, progress, onSelect, onBack }) => {
  const levels = Array.from({ length: MAX_LEVELS }, (_, i) => i + 1);

  return (
    <div className="max-w-4xl mx-auto px-6 py-12">
      <header className="mb-10">
        <div className="flex items-center justify-between mb-6">
          <button 
            onClick={onBack}
            className="text-gray-400 hover:text-white transition-colors flex items-center gap-2"
          >
            ← BACK
          </button>
          <div className="text-right">
             <span className="text-xs text-gray-500 uppercase block">Subject</span>
             <span className="font-bold text-xl uppercase">{subject.title}</span>
          </div>
        </div>
        <div className="h-1 w-full bg-zinc-800">
           <div 
             className="h-full bg-white transition-all duration-1000" 
             style={{ width: `${(Object.values(progress).filter((p: LevelProgress) => p.completed).length / MAX_LEVELS) * 100}%` }}
           ></div>
        </div>
        <div className="mt-2 text-xs text-gray-500 flex justify-between uppercase">
          <span>0% Mastery</span>
          <span>100% Mastery</span>
        </div>
      </header>

      <div className="grid grid-cols-4 sm:grid-cols-5 md:grid-cols-10 gap-3">
        {levels.map((lvl) => {
          const lp = progress[lvl.toString()] || { unlocked: false, completed: false, stars: 0 };
          const isUnlocked = lp.unlocked;

          return (
            <button
              key={lvl}
              disabled={!isUnlocked}
              onClick={() => onSelect(lvl)}
              className={`
                aspect-square flex flex-col items-center justify-center relative border-2 transition-all
                ${isUnlocked 
                  ? 'bg-zinc-900 border-zinc-700 hover:border-white hover:bg-zinc-800 cursor-pointer' 
                  : 'bg-zinc-950 border-zinc-900 opacity-40 cursor-not-allowed'}
                ${lp.completed ? 'border-zinc-500' : ''}
              `}
            >
              <span className={`text-lg font-bold ${lp.completed ? 'text-white' : 'text-gray-500'}`}>
                {lvl}
              </span>
              
              <div className="flex gap-0.5 mt-1">
                {[...Array(3)].map((_, i) => (
                  <div 
                    key={i} 
                    className={`w-1 h-1 rounded-full ${i < lp.stars ? 'bg-white' : 'bg-zinc-700'}`}
                  ></div>
                ))}
              </div>

              {!isUnlocked && (
                <div className="absolute inset-0 flex items-center justify-center">
                  <span className="text-xs opacity-50">🔒</span>
                </div>
              )}
            </button>
          );
        })}
      </div>
    </div>
  );
};

export default LevelSelection;
