
export type SubjectId = 'GK' | 'GS' | 'PHYSICS' | 'MATH' | 'SSC' | 'ONEDAY';

export interface Question {
  id: string;
  subject: SubjectId;
  level: number;
  text: string;
  options: string[];
  correctAnswer: number; // 0-3
}

export interface LevelProgress {
  score: number;
  stars: number;
  unlocked: boolean;
  completed: boolean;
}

export interface UserProgress {
  [subject: string]: {
    [level: string]: LevelProgress;
  };
}

export interface Subject {
  id: SubjectId;
  title: string;
  description: string;
  icon: string;
}
