
# Quiz X - Master the Mind

Quiz X is a professional-grade quiz application designed for students preparing for competitive exams like SSC, General Science, and Mathematics.

## 📱 Installation (Hindi)
Aap is app ko apne phone par install kar sakte hain:
1. **PWA Method**: Browser mein open karein, 3 dots (Menu) par click karein aur **"Install App"** ya **"Add to Home Screen"** select karein.
2. **APK Method**: APK banane ke liye [PWA2APK](https://pwa2apk.com/) ya [Bubblewrap](https://github.com/GoogleChromeLabs/bubblewrap) ka use karein.

## Features
- **6 Categories**: GK, GS, Physics, Mathematics, SSC, and One Day Exam.
- **50 Levels per Subject**: Progressively difficult challenges.
- **Progress Persistence**: Your scores and unlocked levels are saved locally on your device.
- **Interactive UI**: Real-time feedback, vibration effects on errors, and smooth transitions.
- **Offline First**: Works without internet once installed.

## Tech Stack
- **Frontend**: React 19, TypeScript
- **Styling**: Tailwind CSS
- **App Type**: Progressive Web App (PWA)
